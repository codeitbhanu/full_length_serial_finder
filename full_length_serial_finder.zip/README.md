### - Install python 3.7 or higher

[https://www.python.org/ftp/python/3.7.3/python-3.7.3-amd64.exe]

### - Install pip installer setup

curl https://bootstrap.pypa.io/get-pip.py -o get-pip.py
python get-pip.py
[https://phoenixnap.com/kb/install-pip-windows]

### - Intall python packages listed below

    (1) pyodbc
    (2) pandas
    (3) openpyxl

    eg. pip install <package name>

### - Put the XLSX list file in same directory as script main.py

### - Modify main.py as need

### - Run the python script main.py using python 3
